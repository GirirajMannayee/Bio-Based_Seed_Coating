# Updated Data Availability Statement (for manuscript)

Replace the current Data Availability Statement with the following (insert your
actual repository host and DOI/URL once deposited, e.g. Zenodo, Figshare, or a
GitHub release):

---

**Data Availability Statement**

The datasets, analysis code, and figures generated in this study are openly
available in a public repository: [repository name/host], [DOI or URL].
The repository contains: (i) the L27(3^13)-structured, 999-run synthetic
coating-process dataset and the code used to generate it (Section 3.4); (ii)
the simulated 8-treatment x 5-replicate green-gram biological-trial dataset
and the code used to generate it (Section 3.6); (iii) the six-model
machine-learning benchmark, the retained XGBoost model, and the SHAP
feature-importance analysis (Section 4.2-4.3, Tables 4-5, Figures 5-7); (iv)
the one-way ANOVA and Tukey HSD statistical analysis underlying Table 6 and
Figures 8-9; and (v) the multi-objective optimization analysis underlying
Table 7 and Figure 10. As noted in Sections 3.6 and 5.1, both datasets are
computationally generated (synthetic coating-process data; calibrated
biological-trial simulation) rather than drawn from physical coating runs or
a wet-lab plant trial, and are provided to enable full reproduction of the
analytical pipeline ahead of planned empirical validation. Raw experimental
data, once collected, will be deposited in an updated version of the same
repository.

---
